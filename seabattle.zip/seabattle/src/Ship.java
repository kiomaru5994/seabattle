import java.util.ArrayList;

class Ship {
    int size;

    Ship(int size) {
        this.size = size;
    }

}
